
  # Build Interactive Storybook Website

  This is a code bundle for Build Interactive Storybook Website. The original project is available at https://www.figma.com/design/bZKbc3GE2AlIlLo89i8aOl/Build-Interactive-Storybook-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  